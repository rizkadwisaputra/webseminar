<?php  
	if (isset($_GET['hapus'])) {
		$artikel->hapus_artikel($_GET['hapus']);
		echo "<script>alert('Data Terhapus');</script>";
		echo "<script>window.location='index.php?halaman=artikel';</script>";
	}
?>

<div class="row">
	<div class="col-md-12">
		<div class="box">
			<div class="box-header">
			<h3 class="box-title">Artikel</h3>
			</div>
			<div class="box-body">
				<table class="table" id="tabelku">
					<thead>
						<tr>
							<th>No</th>
							<th>Judul</th>
							<th>Tanggal</th>
							<th>Isi</th>
							<th>Gambar</th>
							<th>Aksi</th>
						</tr>
					</thead>
					<tbody>
						<?php  
							$art = $artikel->tampil_artikel();
							foreach ($art as $index => $data) {
						?>
						<tr>
							<td><?php echo $index + 1; ?></td>
							<td><?php echo $data['judul']; ?></td>
							<td><?php echo $data['tanggal']; ?></td>
							<td><?php echo substr(strip_tags($data['isi']), 0,20); ?> ...</td>
							<td><img src="gambar_artikel/<?php echo $data['gambar']; ?>" width="50"></td>
							<td>
								<a href="index.php?halaman=ubahartikel&idar=<?php echo $data['id_artikel']; ?>" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Ubah</a>
								<a href="index.php?halaman=artikel&hapus=<?php echo $data['id_artikel']; ?>" class="btn btn-danger btn-xs"><i class="fa fa-remove"></i> Hapus</a>
							</td>
						</tr>
						<?php } ?>
					</tbody>
				</table>
			</div>
			<div class="box-footer">
				<a href="index.php?halaman=tambahartikel" class="btn btn-primary btn-sm">Tambah Data</a>
			</div>
		</div>
	</div>
</div>