
<?php  
	session_start();
	date_default_timezone_set("Asia/Jakarta");
	class basisdata{
		private $host = "localhost";
		private $user = "root";
		private $pass = "";
		private $mydb = "webseminar";

		//method koneksi
		public function sambungkan(){
			//koneksi ke host
			mysql_connect($this->host,$this->user,$this->pass) or die("gak konek");
			//memilih database
			mysql_select_db($this->mydb) or die("gak ada databasenya");
		}
	}
	class user{
		public function tampil_user(){
			$ambil = mysql_query("SELECT * FROM user");
			//pecah terus di ulang di while
			while ($pecah = mysql_fetch_array($ambil)) {
				$data[] = $pecah;
			}
			return $data;
		}
		public function simpan_user($nama,$email,$pass){
			mysql_query("INSERT INTO user(nama,email,password) VALUES('$nama','$email','$pass')");
		}
		public function hapus_user($hapus){
			mysql_query("DELETE FROM user WHERE id_user = '$hapus'");
		}
		public function login_user($username,$pass){
			// mencocokan data di db dengan username dan pass yang di inputkan
			$cek = mysql_query("SELECT * FROM user WHERE email='$username' AND password='$pass'");
			//mengambil data orang yang login dan cocok
			$data = mysql_fetch_assoc($cek);
			// hitung data yang cocok
			$cocokan = mysql_num_rows($cek);
			//jika akun yang cocok lebih besar dari 0 maka bisa login
			if ($cocokan > 0) {
				//bisa login
				$_SESSION['login_user']['idku'] = $data['id_user'];
				$_SESSION['login_user']['emailku'] = $data['email'];
				$_SESSION['login_user']['namaku'] = $data['nama'];
				return true;
			}// selain itu (akun yang cocok tdk lebih dari 0) maka ggl
			else{
				return false;
			}
		}
		public function ambil_user($idu){
			$ambil = mysql_query("SELECT * FROM user WHERE id_user = '$idu'");
			$pecah = mysql_fetch_assoc($ambil);

			return $pecah;
		}
		public function ubah_user($nama,$email,$pass,$idu){
			mysql_query("UPDATE user SET nama='$nama', email='$email', password='$pass' WHERE id_user='$idu'");		
		}

	}
	class artikel{
		public function tampil_artikel(){
			//mengambil data artikel
			$ambil = mysql_query("SELECT * FROM artikel");
			//memecah data array dan di perulangkan
			while ($pecah = mysql_fetch_array($ambil)) {
				//mengambil dalam 1 array
				$data[] = $pecah;
			}
			return $data;
		}
		public function simpan_artikel($judul,$isi,$gambar){
			//mengambil nama gambar
			$namafile = $gambar['name'];
			//lokasi file atau foto
			$lokasifile = $gambar['tmp_name'];
			//menguplod file
			move_uploaded_file($lokasifile, "gambar_artikel/$namafile");
			//mengambil tanggal saat ini
			$tanggal = date('Y-m-d H:i:s');
			//query insert data
			mysql_query("INSERT INTO artikel(judul,tanggal,isi,gambar) VALUES('$judul','$tanggal','$isi','$namafile')");
		}
		public function hapus_artikel($hapus){
			$pecah = $this->ambil_artikel($hapus);
			$namafile = $pecah['gambar'];
			unlink("gambar_artikel/$namafile");

			mysql_query("DELETE FROM artikel WHERE id_artikel = '$hapus' ");
		}
		public function ambil_artikel($hapus){
			$ambil = mysql_query("SELECT * FROM artikel WHERE id_artikel='$hapus'");
			$pecah = mysql_fetch_assoc($ambil);

			return $pecah;
		}
		public function ubah_artikel($judul,$isi,$gambar,$idar){
			//nama gambar
			$namafile = $gambar['name'];
			//lokasi gambar sementara
			$lokasifile = $gambar['tmp_name'];
			$pecah = $this->ambil_artikel($idar);
			//namafile gambar yang mau di hapus gambar sebelumnya loh
			$gambarhapus = $pecah['gambar'];
			//tanggal saat ini
			$tanggal = date('Y-m-d H:i:s');
			if (!empty($lokasifile)) {
				//hapus gambar lama
				unlink("gambar_artikel/$gambarhapus");
				//upload gambar baru
				move_uploaded_file($lokasifile, "gambar_artikel/$namafile");
				
				//update
			mysql_query("UPDATE artikel SET judul='$judul', tanggal='$tanggal', isi='$isi', gambar='$namafile' WHERE id_artikel = '$idar'");
			}
			else{
				mysql_query("UPDATE artikel SET judul='$judul', tanggal='$tanggal', isi='$isi' WHERE id_artikel = '$idar'");
			}
		}
	}

	class seminar{
		public function tampil_seminar(){
			$ambil = mysql_query("SELECT * FROM seminar S JOIN detail_seminar DS ON S.id_seminar = DS.id_seminar");
			while ($pecah = mysql_fetch_array($ambil)) {
				$data[] = $pecah;
			}
			return $data;
		}
		public function detail_seminar($idsem){
			$ambil = mysql_query("SELECT * FROM seminar S JOIN detail_seminar DS ON S.id_seminar = DS.id_seminar 
				WHERE S.id_seminar = '$idsem' AND DS.id_seminar = '$idsem'");
			$pecah = mysql_fetch_assoc($ambil);
			return $pecah;
		}
		public function ambil_kode(){
			$ambil = mysql_query("SELECT * FROM detail_seminar ORDER BY id_seminar DESC LIMIT 1");
			$pecah = mysql_fetch_array($ambil);

			return $pecah;
		}
		public function simpan_seminar($namasem,$tglsel,$tglmul,$lokasi,$gambar,$keterangan){

			//mengambil nama gambar
			$namafile = $gambar['name'];
			//lokasi file atau foto
			$lokasifile = $gambar['tmp_name'];
			//menguplod file
			move_uploaded_file($lokasifile, "gambar_seminar/$namafile");
			//mengambil tanggal saat ini
			$tanggal = date('Y-m-d');
			//query insert data
			mysql_query("INSERT INTO detail_seminar(nama_seminar,tgl_mulai,tgl_selesai,tglmulai_seminar,lokasi,gambar,keterangan) 
				VALUES('$namasem','$tanggal','$tglsel','$tglmul','$lokasi','$namafile','$keterangan')");
		}
		public function ubah_seminar($namasem,$tglsel,$tglmul,$lokasi,$gambar,$keterangan,$idsem){
			//nama gambar
			$namafile = $gambar['name'];
			//lokasi gambar sementara
			$lokasifile = $gambar['tmp_name'];
			$pecah = $this->ambil_seminar($idsem);
			//namafile gambar yang mau di hapus gambar sebelumnya loh
			$gambarhapus = $pecah['gambar'];
		
			if (!empty($lokasifile)) {
				//hapus gambar lama
				unlink("gambar_seminar/$gambarhapus");
				//upload gambar baru
				move_uploaded_file($lokasifile, "gambar_seminar/$namafile");
				
				//update
			mysql_query("UPDATE detail_seminar SET nama_seminar='$namasem', tgl_selesai='$tglsel', tglmulai_seminar='$tglmul', lokasi='$lokasi', gambar='$namafile', keterangan='$keterangan' WHERE id_seminar = '$idsem'");
			}
			else{
				mysql_query("UPDATE detail_seminar SET nama_seminar='$namasem', tgl_selesai='$tglsel', tglmulai_seminar='$tglmul', lokasi='$lokasi', keterangan='$keterangan' WHERE id_seminar = '$idsem'");
			}	
		}
		public function simpan_status($idsem){
			mysql_query("INSERT INTO seminar (id_seminar,status) VALUES ('$idsem','BUKA')");
		}
		public function ubah_status($idsem){
			$tanggal = date("Y-m-d");
			$sem = $this->ambil_seminar($idsem);
			if ($sem['tgl_selesai'] == "$tanggal") {
				mysql_query("UPDATE seminar SET status='TUTUP'");
			}
			else{
				mysql_query("UPDATE seminar SET status='BUKA'");
			}
		}
		public function cek_seminar(){
			$tanggal = date("Y-m-d");
			$sem = $this->tampil_seminar();
			foreach ($sem as $index => $data) {
				if ($data['tgl_selesai']<=$tanggal) {
					$idsem = $data['id_seminar'];
					mysql_query("UPDATE seminar SET status='TUTUP' WHERE id_seminar = '$idsem'");
				}
				elseif($data['tgl_selesai']>=$tanggal){
					$idsem = $data['id_seminar'];
					mysql_query("UPDATE seminar SET status='BUKA' WHERE id_seminar = '$idsem'");
				}
			}
		}
		public function ambil_seminar($idsem){
			$ambil = mysql_query("SELECT * FROM detail_seminar WHERE id_seminar = '$idsem'");
			$pecah = mysql_fetch_assoc($ambil);

			return $pecah;
		}

		public function hapus_seminar($hapus){
			$sem = $this->ambil_seminar($hapus);
			$namafile = $sem['gambar'];
			unlink("gambar_seminar/$namafile");
			
			mysql_query("DELETE FROM detail_seminar WHERE id_seminar = '$hapus'");
			mysql_query("DELETE FROM seminar WHERE id_seminar = '$hapus'");
			mysql_query("DELETE * FROM biaya WHERE id_seminar = '$hapus'");
		}

		public function simpan_biaya($idsem,$biaya,$ket){
			mysql_query("INSERT INTO biaya(id_seminar,biaya,keterangan) VALUES('$idsem','$biaya','$ket')");
		}
		public function tampil_ubahbiaya($idsem){
			$ambil = mysql_query("SELECT * FROM biaya WHERE id_seminar = '$idsem'");
			while ($pecah = mysql_fetch_array($ambil)){
				$data[] = $pecah;
			}
			return $data;
		}
		public function ambil_biaya($idsem){
			$ambil = mysql_query("SELECT * FROM biaya WHERE id_seminar = '$idsem'");
			$pecah = mysql_fetch_assoc($ambil);

			return $pecah;
		}
		
		public function ambil_biayaubah($idbi){
			$ambil = mysql_query("SELECT * FROM biaya WHERE id_biaya = '$idbi'");
			$pecah = mysql_fetch_assoc($ambil);

			return $pecah;
		}
		public function ubah_biaya($biaya,$keterangan,$idbi){
			mysql_query("UPDATE biaya SET biaya='$biaya', keterangan='$keterangan' WHERE id_biaya = '$idbi'");
		}
		public function hapus_biaya($hapus){
			mysql_query("DELETE FROM biaya WHERE id_biaya = '$hapus'");
		}
		public function ambil_biayachek($idbi){
			$ambil = mysql_query("SELECT * FROM biaya WHERE id_biaya = '$idbi'");
			$pecah = mysql_fetch_assoc($ambil);
			return $pecah;
		}
		public function registrasi($nim,$nama,$alamat,$telepon,$email,$idmem,$idsem){
			mysql_query("INSERT INTO registrasi(NIM,nama_peserta,alamat,telepon,email,id_seminar,id_member) VALUES('$nim','$nama','$alamat','$telepon','$email','$idsem','$idmem')");
		}
		public function tampil_pembayaran(){
			$ambil = mysql_query("SELECT * FROM pembayaran p JOIN registrasi r ON p.id_peserta = r.id_peserta");
			
			while ($pecah = mysql_fetch_array($ambil)) {
				$data[]=$pecah;
			}
			return $data;
		}
		public function tampil_cetakseminar($idpes){
			$ambil = mysql_query("SELECT * FROM registrasi r JOIN detail_seminar ds ON r.id_seminar=ds.id_seminar WHERE r.id_peserta = '$idpes'");
			$pecah = mysql_fetch_assoc($ambil);
			return $pecah;
		}
		public function tampildetail_pembayaran($idpem){
			$ambil = mysql_query("SELECT * FROM konfirmasi k JOIN pembayaran p ON k.id_peserta=p.id_peserta WHERE p.id_pembayaran = '$idpem'");
			$pecah = mysql_fetch_assoc($ambil);
			return $pecah;
		}
		public function tampil_pembayaran_member($idmem){
			$ambil = mysql_query("SELECT * FROM pembayaran p JOIN registrasi r 
				ON p.id_peserta = r.id_peserta WHERE id_member = '$idmem'");
			while ($pecah = mysql_fetch_array($ambil)) {
				$data[]=$pecah;
			}
			return $data;
		}
		public function ambil_pembayarantiket($idpem){
			$ambil = mysql_query("SELECT * FROM pembayaran WHERE id_pembayaran = '$idpem'");
			$pecah = mysql_fetch_array($ambil);
			return $pecah;
		}
		public function ambil_konfirmasi($idpes){
			$ambil = mysql_query("SELECT * FROM konfirmasi WHERE id_peserta = '$idpes'");
			$pecah = mysql_fetch_array($ambil);
			return $pecah;
		}
		public function ambil_req($idpes){
			$ambil = mysql_query("SELECT * FROM registrasi WHERE id_peserta = '$idpes'");
			return mysql_fetch_assoc($ambil);
		}
		public function simpan_pembayaran($jumbayar){
			$ambil = $this->ambil_kodereq();
			$idpes = $ambil['id_peserta'];
			mysql_query("INSERT INTO pembayaran(id_peserta,jumlah_bayar,status) 
				VALUES('$idpes','$jumbayar','BELUM LUNAS')");
		}
		public function ambil_pembayaran(){
			$ambil =  mysql_query("SELECT * FROM pembayaran ORDER BY id_pembayaran DESC LIMIT 1");
			$pecah = mysql_fetch_assoc($ambil);

			return $pecah;
		}
		public function ambil_kodereq(){
			$ambil = mysql_query("SELECT * FROM registrasi ORDER BY id_peserta DESC LIMIT 1");
			return mysql_fetch_assoc($ambil);
		}
		public function biayareq($idsem,$ket){
			$ambil = mysql_query("SELECT * FROM biaya WHERE id_seminar = '$idsem' AND keterangan='$ket'");
			$pecah = mysql_fetch_assoc($ambil);

			return $pecah;
		}
		public function konfirmasi_pembayaran($namapk,$namab,$norek,$norekt,$totalb,$idpes,$idpem){
			mysql_query("INSERT INTO konfirmasi(nama_pemilik_rek,nama_bank,no_rek,no_rek_tujuan,total_bayar,id_peserta) 
				VALUES('$namapk','$namab','$norek','$norekt','$totalb','$idpes')");
			mysql_query("UPDATE pembayaran SET status='PROSES' WHERE id_pembayaran = '$idpem'");
		}
		public function ubah_pembayaran($idpem){
			mysql_query("UPDATE pembayaran SET status ='LUNAS' WHERE id_pembayaran='$idpem'");
		}
		public function gagal_pembayaran($idpem){
			mysql_query("DELETE FROM pembayaran WHERE id_pembayaran = '$idpem'");
		}
	}
	class member{
		public function tampil_member(){
			//ambil data
			$ambil = mysql_query("SELECT * FROM member");
			//dipecah
			while ($pecah = mysql_fetch_array($ambil)){
				$data[] = $pecah;
			}
			return $data;
		}
		public function simpan_member($nama,$alamat,$email,$password){
			mysql_query("INSERT INTO member(nama,alamat,email,password) VALUES('$nama','$alamat','$email','$password')");
		}
		public function hapus_member($hapus){
			mysql_query("DELETE FROM member WHERE id_member = '$hapus'");
		}
		public function ambil_member($idm){
			$ambil = mysql_query("SELECT * FROM member WHERE id_member = '$idm'");
			$pecah = mysql_fetch_assoc($ambil);

			return $pecah;
		}
		public function ubah_member($nama, $alamat, $email, $pass, $idmem){
			mysql_query("UPDATE member SET nama='$nama', alamat='$alamat', email='$email', password='$pass' WHERE id_member='$idmem'");
		}
		public function ambil_kodemem(){
			$ambil = mysql_query("SELECT * FROM member ORDER BY id_member DESC LIMIT 1");
			return mysql_fetch_assoc($ambil);
		}
		public function login_member($username, $pass){
			$cek = mysql_query("SELECT * FROM member WHERE email='$username' AND password='$pass'");
			$data = mysql_fetch_assoc($cek);
			$cocokan = mysql_num_rows($cek);
			if ($cocokan > 0) {
				$_SESSION['login_member']['idku'] = $data['id_member'];
				$_SESSION['login_member']['emailku'] = $data['email'];
				$_SESSION['login_member']['namaku'] = $data['nama'];
				return true;
			}
			else{
				return false;
			}
		}

	}
	class message{
		public function send_message($nama,$email,$telepon,$isi){
			mysql_query("INSERT INTO message(nama_pengirim,email,telepon,isi) VALUES('$nama','$email','$telepon','$isi')");
		}
		public function tampil_message(){
			$ambil = mysql_query("SELECT * FROM message");
			while ($pecah = mysql_fetch_array($ambil)) {
				$data[]=$pecah;
			}
			return $data;
		}
		public function hapus_message($kd){
			mysql_query("DELETE FROM message WHERE id_message='$kd'");
		}
		public function view_message($kd){
			$ambil = mysql_query("SELECT * FROM message WHERE id_message = '$kd'");
			$pecah = mysql_fetch_array($ambil);

			return $pecah;
		}
	}
	
	$db = new basisdata();
	$db->sambungkan();
	$user = new user();
	$artikel  = new artikel();
	$seminar = new seminar();
	$member = new member();
	$message = new message();
?>