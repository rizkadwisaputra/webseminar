<?php   
	if (isset($_GET['hapus'])) {
		$admin->hapus_admin($_GET['hapus']);
		echo "<script>alert('Data Terhapus');</script>";
		echo "<script>window.location='index.php?halaman=admin';</script>";
	}
?>
<div class="row">
	<div class="col-md-12">
		<div class="box">
			<div class="box-header">
			<h3 class="box-title">Admin</h3>
			</div>
			<div class="box-body">
				<table class="table" id="tabelku">
					<thead>
						<tr>
							<th>No</th>
							<th>Email</th>
							<th>Password</th>
							<th>Nama</th>
							<th>Aksi</th>
						</tr>
					</thead>
					<tbody>
						<?php  
							$adm = $admin->tampil_admin();
							foreach ($adm as $index => $data) {
						?>
						<tr>
							<td><?php echo $index + 1; ?></td>
							<td><?php echo $data['email']; ?></td>
							<td><?php echo $data['password']; ?></td>
							<td><?php echo $data['nama']; ?></td>
							<td>
								<a href="index.php?halaman=ubahadmin&ida=<?php echo $data['id_admin']; ?>" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Ubah</a>
								<a href="index.php?halaman=admin&hapus=<?php echo $data['id_admin']; ?>" class="btn btn-danger btn-xs"><i class="fa fa-remove"></i> Hapus</a>
							</td>
						</tr>
						<?php } ?>
					</tbody>
				</table>
			</div>
			<div class="box-footer">
				<a href="index.php?halaman=tambahadmin" class="btn btn-primary btn-sm">Tambah Data</a>
			</div>
		</div>
	</div>
</div>