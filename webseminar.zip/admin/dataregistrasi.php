<?php  
	if (isset($_GET['hapus'])) {
		$member->hapus_member($_GET['hapus']);
		echo "<script>alert('Data Terhapus');</script>";
		echo "<script>window.location='index.php?halaman=member';</script>";
	}
?>
<div class="row">
	<div class="col-md-12">
		<div class="box">
			<div class="box-header">
				<h3 class="box-title">Data Registrasi Seminar</h3>
			</div>
			<div class="box-body table-responsive">
				<table class="table" id="tabelku">
					<thead>
						<tr>
							<th>No</th>
							<th>Nama Seminar</th>
							<th>Nama Peserta</th>
							<th>Status</th>
							<th>Aksi</th>
						</tr>
					</thead>
					<tbody>
						<?php  
							$pem = $seminar->tampil_pembayaran();
							foreach ($pem as $index => $data) {
							$sem = $seminar->ambil_seminar($data['id_seminar']);
							//$mem = $member->ambil_member($data['id_member']);
						?>
						<tr>
							<td><?php echo $index + 1; ?></td>
							<td><?php echo $sem['nama_seminar']; ?></td>
							<td><?php echo $data['nama_peserta']; ?></td>
							<td><?php echo $data['status']; ?></td>
							<td>
								<a href="viewkonfirmasi.php?idpem=<?php echo $data['id_pembayaran']; ?>" class="btn btn-info btn-xs"><i class="fa fa-search"></i> View</a>
							</td>
						</tr>
						<?php } ?>
					</tbody>
				</table>
			</div>
		</div>
</div>