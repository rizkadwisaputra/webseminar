<?php  
	if (isset($_GET['hapus'])) {
		$message->hapus_message($_GET['hapus']);
		echo "<script>alert('Data Terhapus');</script>";
		echo "<script>window.location='index.php?halaman=message';</script>";
	}
?>
<div class="row">
	<div class="col-md-12">
		<div class="box">
			<div class="box-header">
				<h3 class="box-title">User</h3>
			</div>
			<div class="box-body">
				<table class="table" id="tabelku">
					<thead>
						<tr>
							<th>No</th>
							<th>Nama</th>
							<th>Email</th>
							<th>Telepon</th>
							<th>Isi</th>
							<th>Aksi</th>
						</tr>
					</thead>
					<tbody>
						<?php  
							$msg = $message->tampil_message();
							foreach ($msg as $index => $data) {
						?>
						<tr>
							<td><?php echo $index + 1; ?></td>
							<td><?php echo $data['nama_pengirim']; ?></td>
							<td><?php echo $data['email']; ?></td>
							<td><?php echo $data['telepon']; ?></td>
							<td><?php echo substr(strip_tags($data['isi']), 0,20); ?></td>
							<td>
								<a href="index.php?halaman=message&hapus=<?php echo $data['id_message']; ?>" class="btn btn-danger btn-xs"><i class="fa fa-pencil"></i> Hapus</a>
								<a href="index.php?halaman=viewmessage&id=<?php echo $data['id_message']; ?>" class="btn btn-info btn-xs"><i class="fa fa-search"></i> View</a>
							</td>
						</tr>
						<?php } ?>
					</tbody>
				</table>
			</div>
		</div>
</div>