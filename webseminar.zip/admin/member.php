<?php  
	if (isset($_GET['hapus'])) {
		$member->hapus_member($_GET['hapus']);
		echo "<script>alert('Data Terhapus');</script>";
		echo "<script>window.location='index.php?halaman=member';</script>";
	}
?>
<div class="row">
	<div class="col-md-12">
		<div class="box">
			<div class="box-header">
				<h3 class="box-title">User</h3>
			</div>
			<div class="box-body">
				<table class="table" id="tabelku">
					<thead>
						<tr>
							<th>No</th>
							<th>Nama</th>
							<th>Email</th>
							<th>Password</th>
							<th>Aksi</th>
						</tr>
					</thead>
					<tbody>
						<?php  
							$mbr = $member->tampil_member();
							foreach ($mbr as $index => $data) {
						?>
						<tr>
							<td><?php echo $index + 1; ?></td>
							<td><?php echo $data['nama']; ?></td>
							<td><?php echo $data['email']; ?></td>
							<td><?php echo $data['password']; ?></td>
							<td>
								<a href="index.php?halaman=member&hapus=<?php echo $data['id_member']; ?>" class="btn btn-danger btn-xs"><i class="fa fa-pencil"></i> Hapus</a>
							</td>
						</tr>
						<?php } ?>
					</tbody>
				</table>
			</div>
		</div>
</div>