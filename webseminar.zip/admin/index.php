<?php 
  include 'class.php';
  $seminar->cek_seminar();
  if (empty($_SESSION['login_user'])) {
    echo "<script>alert('Login Dulu');</script>";
    echo "<script>window.location='login.php';</script>";
  }
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>AdminIMK | Web Seminar</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="font-awesome-4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
    <link rel="stylesheet" href="dist/css/skins/skin-blue.min.css">
    <link rel="stylesheet" href="plugins/datatables/dataTables.bootstrap.css">
  </head>
  <body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">

      <!-- Main Header -->
      <header class="main-header">

        <!-- Logo -->
        <a href="index.php" class="logo">
          <!-- mini logo for sidebar mini 50x50 pixels -->
          <span class="logo-mini"><b>I</b>MK</span>
          <!-- logo for regular state and mobile devices -->
          <span class="logo-lg"><b>Admin</b>IMK</span>
        </a>

        <!-- Header Navbar -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
          </a>
          <!-- Navbar Right Menu -->
          <div style="float:right;">
                <a href="index.php?halaman=logout" class="btn btn-danger" style="margin-top:8px; margin-right:5px;">Logout</a> 
          </div>
        </nav>
      </header>
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- Sidebar user panel (optional) -->
          <div class="user-panel">
            <div class="pull-left image">
              <img src="dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
              <p></p>
              <!-- Status -->
              <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
          </div>

          <!-- search form (Optional) -->
          <form action="#" method="get" class="sidebar-form">
            <div class="input-group">
              <input type="text" name="q" class="form-control" placeholder="Search...">
              <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i></button>
              </span>
            </div>
          </form>
          <!-- /.search form -->

          <!-- Sidebar Menu -->
          <ul class="sidebar-menu">
            <li class="header">HEADER</li>
            <!-- Optionally, you can add icons to the links -->
            <li><a href="index.php"><i class="fa fa-link"></i> <span>Dashboard</span></a></li>
            <li><a href="index.php?halaman=user"><i class="fa fa-user"></i> <span>User</span></a></li>
            <li><a href="index.php?halaman=artikel"><i class="fa fa-pencil-square-o"></i> <span>Artikel</span></a></li>
            <li><a href="index.php?halaman=seminar"><i class="fa fa-users"></i> <span>Seminar</span></a></li>
            <li><a href="index.php?halaman=member"><i class="fa fa-users"></i> <span>Member</span></a></li>
            <li><a href="index.php?halaman=dataregistrasi"><i class="fa fa-users"></i> <span>Data Registrasi</span></a></li>
            <li><a href="index.php?halaman=message"><i class="fa fa-inbox"></i> <span>Message</span></a></li>
          </ul><!-- /.sidebar-menu -->
        </section>
        <!-- /.sidebar -->
      </aside>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Main content -->
        <section class="content">
          <?php 
          if (isset($_GET['halaman'])){
            if ($_GET['halaman']=="user") {
               include 'user.php';
             } 
             elseif ($_GET['halaman']=="tambahuser") {
               include 'tambahuser.php';
             }
             elseif ($_GET['halaman']=="ubahuser") {
               include 'ubahuser.php';
             }
             elseif ($_GET['halaman']=="artikel") {
               include 'artikel.php';
             }
             elseif ($_GET['halaman']=="tambahartikel") {
               include 'tambahartikel.php';
             }
             elseif ($_GET['halaman']=="ubahartikel") {
               include 'ubahartikel.php';
             }
             elseif ($_GET['halaman']=="seminar") {
               include 'seminar.php';
             }
             elseif ($_GET['halaman']=="ubahseminar") {
               include 'ubahseminar.php';
             }
             elseif ($_GET['halaman']=="viewseminar") {
               include 'viewseminar.php';
             }
             elseif ($_GET['halaman']=="tambahseminar") {
               include 'tambahseminar.php';
             }
             elseif ($_GET['halaman']=="tambahbiaya") {
               include 'tambahbiaya.php';
             }
             elseif ($_GET['halaman']=="uptambahbiaya") {
               include 'uptambahbiaya.php';
             }
             elseif ($_GET['halaman']=="tambahbiayaubah") {
               include 'tambahbiayaubah.php';
             }
             elseif ($_GET['halaman']=="tampilubahbiaya") {
               include 'tampilubahbiaya.php';
             }
             elseif ($_GET['halaman']=="ubahbiaya") {
               include 'ubahbiaya.php';
             }
             elseif ($_GET['halaman']=="dataregistrasi") {
               include 'dataregistrasi.php';
             }
             elseif ($_GET['halaman']=="member") {
               include 'member.php';
             }
             elseif ($_GET['halaman']=="logout") {
              session_destroy();
              echo "<script>window.location='login.php';</script>";
             }
             elseif ($_GET['halaman']=="message") {
               include 'message.php';
             }
             elseif ($_GET['halaman']=="viewmessage") {
               include 'viewmessage.php';
             }
          }
          else{
            include 'dashboard.php';
          }  
          ?>
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

      <!-- Main Footer -->
      <footer class="main-footer">
        <!-- To the right -->
        <div class="pull-right hidden-xs">
          Anything you want
        </div>
        <!-- Default to the left -->
        <strong>Copyright &copy; 2015 <a href="#">S1-TI-02</a>.</strong> All rights reserved.
      </footer>
    </div><!-- ./wrapper -->

    <!-- REQUIRED JS SCRIPTS -->

    <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js"></script>
    <script src="plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="plugins/datatables/dataTables.bootstrap.min.js"></script>
    <script>
      $(function () {
        $("#tabelku").DataTable();

      });
    </script>
    <script src="ckeditor/ckeditor.js"></script>
    <script>
      CKEDITOR.replace('editorku');
    </script>
  </body>
</html>
